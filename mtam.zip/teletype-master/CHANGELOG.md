See https://github.com/atom/teletype/releases
